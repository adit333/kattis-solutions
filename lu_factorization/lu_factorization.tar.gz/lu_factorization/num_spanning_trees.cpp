/* https://en.wikipedia.org/wiki/Kirchhoff%27s_theorem

The input is assumed to be as so:
The first line is V, the no. of vertices in the graph
This is followed by V lines:
    - The first number is k, the no. of vertices this vertex is connected to.
    - this is followed by k numbers, the vertices it is connected to.
The vertices are numbered from 0, so we have: 0, 1, 2, ..., V-1
*/

#include <bits/stdc++.h>
#include "lu_factorizer.h"

using namespace std;

int main() {
    int V;
    cin >> V;

    vector<vector<double>> laplacian(V,vector<double>(V, 0));

    for (int i = 0; i < V; ++i) {
        int k;
        cin >> k;
        laplacian[i][i] = k;
        for (int j = 0; j < k; ++j) {
            int v; cin >> v;
            laplacian[i][v] = -1;
        }
    }

    // Now delete the last row and the last column
    for (int i = 0; i < V; ++i)
        laplacian[i].pop_back();
    laplacian.pop_back();

    LUFactorizer luf;
    luf.fit(laplacian);
    cout << luf.determinant(laplacian) << endl;
}