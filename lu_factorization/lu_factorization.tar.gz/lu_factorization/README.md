# **LU Factorization**

LU Factorization decomposes a nonsingular square matrix into a lower-triangular matrix, L, and an upper-triangular matrix, U.

The running time of the algorithm (Gaussian elimination) is O(n^3).

The space complexity is O(n^2). The factorization is done in place, meaning that both L and U are stored in the input A.
This is possible as both are triangular matrices and the diagonal entries of L are always 1 and therefore need not be stored and can be replaced with 1 implicitly for further calculations.

## **Applications**

### **Ax = b**
We can then solve a system of linear equations Ax = b, by solving LU = b. We can solve Ly = b, by forward-substitution and then solve Ux = y by backward-substitution.
The advantage with this approach is that, we only need to factorize A once into LU and then we can reuse the same LU for different RHS b vectors.

The running time for both forward- and backward-substitution is O(n^2)

### **Determinant**
We can use the handy formula: If A = LU, then det(A) = det(L) x det(U).
Since we have triangular matrices, the determinant is simply the product of the diagonals. Therefore, we can compute the determinant in O(n) time by computing the product of diagonals of U. Note that the product of the diagonal of L is 1.

#### Counting the Number of Spanning Trees in a Graph
Given this handy tool we can determine the number of spanning trees in a graph using **Kirchhoff's Theorem**.

We form the Laplacian matrix, delete a row and column of the same index, and then simply calculate its determinant.

The file `num_of_spanning_trees.cpp` does exactly this.
It expects input of the form:
* The first line is V, the no. of vertices in the graph
* This is followed by V lines:
    - The first number is k, the no. of vertices this vertex is connected to.
    - this is followed by k numbers, the vertices it is connected to.
* The vertices are numbered from 0, so we have: 0, 1, 2, ..., V-1

## **Building**
The following files are included:
* `lu_factorizer.h`
* `lu_factorizer_test.cpp`
* `num_of_spanning_trees.cpp`
* `graph1.txt`
* `makefile`

Running `make` command will build two targets `lu_factorizer_test` and `num_of_spanning_trees`.

Running `lu_factorizer_test` will run test cases for `lu_factorizer`.

Run `num_of_spanning_trees` by giving it input as specified above. One could use `graph1.txt` as a starting point; this graph has 8 spanning trees.

The class `LUFactorizer` has the logic for LU Factorization. The whole file is placed in the header file `lu_factorizer.h`. The reason for doing this is that it simplifies the use.

`LUFactorizer` has the following API:
* `bool fit(vector<vector<double>> &A)`
    - Pass in a square matrix by reference. The factorization is done in place
    - `false` is returned if the matrix is singular.

***Note: The following methods should only be called after first calling `fit()`; otherwise the result will be unexpected***

* `void solve_for_b(vector<vd> &A, vd &b, vd &x)`
    - The vector `x` will store the answer.
* `double determinant(vector<vector<double>> &A)`
    - Returns the determinant of the matrix.
* `void print_lu(vector<vector<double>> &A)`
    - Prints the L and U matrices
* `void print_vector(vector<double> &x)`

Run `make clean` to clean up all the object files and executables produced.

## **Resources**
* Introduction to Algorithms, Chapter 28.
* https://en.wikipedia.org/wiki/Kirchhoff%27s_theorem
